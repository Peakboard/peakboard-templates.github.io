﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PeakboardAPIDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Uri uri = new Uri($"http://{this.IPTextBox.Text}:40404/api/datapush?id={this.IdTextBox.Text}&datakey=messages");
                HttpClient httpClient = new HttpClient(new HttpClientHandler() { Credentials = new NetworkCredential(this.UserTextBox.Text, this.PasswordTextBox.Password) });

                var request = new HttpRequestMessage(HttpMethod.Get, uri);

                string csvcontent = "Code,Message\r\n" + this.CodeTextBox.Text + "," + this.MessageTextBox.Text;


                var content = new StringContent(csvcontent, Encoding.UTF8, "application/csv");


                HttpResponseMessage response = await httpClient.PostAsync(uri, content);


                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Message posted successfully");
                }
                else
                {
                    MessageBox.Show($"Message posting failed {response.StatusCode}");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
